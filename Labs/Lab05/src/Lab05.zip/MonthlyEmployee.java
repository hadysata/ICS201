
public class MonthlyEmployee extends Staff {

    public MonthlyEmployee(String name, String phone , double pay) {
        super(name, phone, pay);
    }
}
