
public class Volunteer extends Staff {

    public Volunteer(String name, String phone) {
        super(name, phone, 0.0);
    }
    

}
