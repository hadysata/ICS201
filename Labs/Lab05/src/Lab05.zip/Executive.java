
public class Executive extends Staff {

    public Executive(String name, String phone, double pay) {
        super(name, phone, pay);
    }

}
